package com.spring.project.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Purchase {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  Long id;

  @ManyToOne
  @JoinColumn(name = "user_id")
  User user;

  @ManyToOne
  @JoinColumn(name = "book_id")
  Book book;

  String purchasedat;

  int amount;

  public Purchase() {
  }

  public Purchase(Long id, User user, Book book, String purchasedat, int amount) {
    this.id = id;
    this.user = user;
    this.book = book;
    this.purchasedat = purchasedat;
    this.amount = amount;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  public Book getBook() {
    return book;
  }

  public void setBook(Book book) {
    this.book = book;
  }

  public String getPurchasedAt() {
    return purchasedat;
  }

  public void setPurchasedAt(String purchasedAt) {
    this.purchasedat = purchasedat;
  }

  public int getSale() {
    return amount;
  }

  public void setSale(int sale) {
    this.amount = sale;
  }
}
