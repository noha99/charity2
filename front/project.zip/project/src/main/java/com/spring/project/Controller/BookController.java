package com.spring.project.Controller;

import com.spring.project.Service.BookRepository;
import com.spring.project.model.Book;
import com.spring.project.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "books")
public class BookController {
  @Autowired
  private BookRepository bookRepo;

  @GetMapping("/get")
  public ResponseEntity<List<Book>> getUsers() {
    List<Book> bookList;
    bookList = bookRepo.findAll();
    if (bookList.isEmpty()) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    } else {
      return new ResponseEntity<>(bookList, HttpStatus.OK);
    }
  }

  @PostMapping("/add")
  public ResponseEntity<Book> createBook(@RequestBody Book newBook) {
    try {
//      Book _newBook = bookRepo.save(new Book(newBook.getAuthor(), newBook.getDate(),
//        newBook.getDetail(), newBook.getPrice(), newBook.getRating(), newBook.getTitle(), newBook.getUrl()));
      bookRepo.save(newBook);
      return new ResponseEntity<>(newBook, HttpStatus.CREATED);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }

  }

  @PutMapping("/update")
  public ResponseEntity<Book> updateBook(@RequestBody Book book) {
    try {
      bookRepo.save(book);
      return new ResponseEntity<>(book, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @DeleteMapping(path = { "/{id}" })
  public ResponseEntity<Book> deleteBook(@PathVariable("id") Long id) {
    try {
      Book book = getBookById(id);
      bookRepo.deleteById(id);
      return new ResponseEntity<>(book, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }
  }

  public Book getBookById(Long id) {
    Optional<Book> bookData = bookRepo.findById(id);
    return bookData.orElse(null);
  }

}
