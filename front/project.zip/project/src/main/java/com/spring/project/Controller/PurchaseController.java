package com.spring.project.Controller;

import com.spring.project.Service.PurchaseRepository;
import com.spring.project.model.Purchase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "purchase")
public class PurchaseController {
  @Autowired
  private PurchaseRepository purchaseRepo;


  @GetMapping("/get")
  public ResponseEntity<List<Purchase>> getPurchasedBooks() {
    List<Purchase> purchasesList;
    purchasesList = purchaseRepo.findAll();

    if (purchasesList.isEmpty()) {
      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    } else {
      return new ResponseEntity<>(purchasesList, HttpStatus.OK);
    }
  }

  @PostMapping("/add")
  public ResponseEntity<Purchase> purchaseBook(@RequestBody Purchase newRec) {
    try {
      purchaseRepo.save(newRec);
      return new ResponseEntity<>(newRec, HttpStatus.CREATED);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }

  }

  @PutMapping("/update")
  public ResponseEntity<Purchase> updatePurchaseDetails(@RequestBody Purchase rec) {
    try {
      purchaseRepo.save(rec);
      return new ResponseEntity<>(rec, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @DeleteMapping(path = { "/{id}" })
  public ResponseEntity<Purchase> deleteRec(@PathVariable("id") Long id) {
    try {
      Purchase rec = getRecById(id);
      purchaseRepo.deleteById(id);
      return new ResponseEntity<>(rec, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }
  }

  public Purchase getRecById(Long id) {
    Optional<Purchase> Data = purchaseRepo.findById(id);
    return Data.orElse(null);
  }

}
