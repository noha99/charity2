package com.spring.project.model;

import javax.persistence.*;

import java.util.Set;

import static sun.swing.MenuItemLayoutHelper.max;

@Entity
@Table(name = "book")
public class Book {

  @Id
  @Column(name = "id")
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(name = "title")
  private String title;

  @Column(name = "author")
  private String author;

  @Column(name = "price")
  private String price;

  @Column(name = "detail" , columnDefinition="TEXT")
  private String detail;

  @Column(name = "date")
  private String date;

  @Column(name = "rating")
  private String rating;

  @Column(name = "url")
  private String url;

  @OneToMany(mappedBy = "book")
  Set<Purchase> purchases;

  public Book(String title, String author, String price, String detail, String date, String rating, String url) {
  }

  public Book() {

  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getDetail() {
    return detail;
  }

  public void setDetail(String detail) {
    this.detail = detail;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public String getRating() {
    return rating;
  }

  public void setRating(String rating) {
    this.rating = rating;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public String getPrice() {
    return price;
  }

  public void setPrice(String price) {
    this.price = price;
  }


}
